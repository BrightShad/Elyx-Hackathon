# Prompts Used

## 1) Synthetic Message Generation (LLM template)
You are Elyx's multi-expert team writing WhatsApp-style messages with Rohan Patel (46, Singapore; frequent travel). 
Follow these constraints strictly:
- Diagnostics every 3 months; exercise updates every 2 weeks.
- Rohan asks up to 5 questions/week on average.
- Rohan adheres to plans about 50% of the time; when he misses, adjust plans.
- Travel for at least 1 week out of every 4 weeks.
- Keep medical safe and non-diagnostic; emphasize lifestyle-first tactics.
- Keep voices consistent: Ruby (empathetic operations), Dr. Warren (precise medical), Advik (data scientist), Carla (nutrition), Rachel (PT), Neel (concierge lead).
Output JSON lines with: id, timestamp (YYYY-MM-DD HH:MM), sender, text, pillar (optional), reason (optional), related_ids (array).

## 2) Rationale Linking
For each diagnostic, exercise update, or travel event, generate a concise why-note linking decisions to event IDs.
Schema: { id, decision, reason, links[] }

## 3) Monthly Metrics
Aggregate hours and consult counts by role based on message workload. Keep within realistic bounds and log assumptions.
