async function loadJSON(path){
  const res = await fetch(path, {cache: "no-store"});
  if(!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  return res.json();
}

const state = {
  messages: [], events: [], rationales: [], metrics: [],
  pillar: "", sender: "", search: "", sort: "asc"
};

function formatDate(ts){
  // Accepts "YYYY-MM-DD HH:MM:SS" or ISO; shows local
  const d = new Date(ts.replace(' ', 'T'));
  return d.toLocaleString();
}

function el(tag, cls, text){
  const e = document.createElement(tag);
  if(cls) e.className = cls;
  if(text !== undefined) e.textContent = text;
  return e;
}

function renderFilters(){
  const pSel = document.getElementById('pillar');
  const sSel = document.getElementById('sender');
  const sortSel = document.getElementById('sort');
  const search = document.getElementById('search');

  const pillars = Array.from(new Set(state.messages.map(m=>m.pillar).filter(Boolean))).sort();
  const senders = Array.from(new Set(state.messages.map(m=>m.sender))).sort();
  for(const p of pillars){ const o=document.createElement('option'); o.value=p; o.textContent=p; pSel.appendChild(o); }
  for(const s of senders){ const o=document.createElement('option'); o.value=s; o.textContent=s; sSel.appendChild(o); }

  pSel.onchange = ()=>{ state.pillar = pSel.value; syncURL(); renderTimeline(); };
  sSel.onchange = ()=>{ state.sender = sSel.value; syncURL(); renderTimeline(); };
  sortSel.onchange = ()=>{ state.sort = sortSel.value; syncURL(); renderTimeline(); };

  const debounced = debounce((v)=>{ state.search = v.toLowerCase(); syncURL(); renderTimeline(); }, 250);
  search.addEventListener('input', (e)=> debounced(e.target.value));

  // Restore state from URL on first load
  const params = new URLSearchParams(location.search);
  if(params.has('pillar')){ state.pillar = params.get('pillar'); pSel.value = state.pillar; }
  if(params.has('sender')){ state.sender = params.get('sender'); sSel.value = state.sender; }
  if(params.has('search')){ state.search = params.get('search'); search.value = state.search; }
  if(params.has('sort')){ state.sort = params.get('sort'); sortSel.value = state.sort; }
}

function syncURL(){
  const params = new URLSearchParams();
  if(state.pillar) params.set('pillar', state.pillar);
  if(state.sender) params.set('sender', state.sender);
  if(state.search) params.set('search', state.search);
  if(state.sort && state.sort !== 'asc') params.set('sort', state.sort);
  history.replaceState(null, "", `${location.pathname}?${params.toString()}`);
}

function messageEl(m){
  const tpl = document.getElementById('message-tpl');
  const node = tpl.content.firstElementChild.cloneNode(true);
  if(m.pillar){ node.dataset.pillar = m.pillar; node.querySelector('.badge').textContent = m.pillar; }
  node.querySelector('.timestamp').textContent = `[${formatDate(m.timestamp)}]`;
  node.querySelector('.sender').textContent = m.sender || "Unknown";
  node.querySelector('.content').textContent = m.text || "";

  const related = node.querySelector('.related');
  if(m.related_ids && m.related_ids.length){
    related.innerHTML = 'Related: ' + m.related_ids.map(x=>`<code>${x}</code>`).join(' ');
    node.addEventListener('click', ()=> highlightRationales(m.related_ids));
  }else{
    related.remove();
  }
  return node;
}

function highlightRationales(ids){
  const rDiv = document.getElementById('rationale');
  rDiv.innerHTML = '';
  const hits = state.rationales.filter(r => r.links?.some(l => ids.includes(l)));
  if(!hits.length){ rDiv.innerHTML = '<p class="muted">No rationale attached.</p>'; return; }
  for(const r of hits){
    const card = el('div', 'message highlight');
    const meta = el('div', 'meta', r.id || '');
    const body = el('div', null);
    body.innerHTML = `<strong>${r.decision || 'Decision'}</strong><br/>Why: ${r.reason || '—'}`;
    card.append(meta, body);
    rDiv.appendChild(card);
  }
}

function renderTimeline(){
  const wrap = document.getElementById('timeline');
  wrap.innerHTML = '';

  let list = state.messages.slice();
  if(state.pillar){ list = list.filter(m=>m.pillar===state.pillar); }
  if(state.sender){ list = list.filter(m=>m.sender===state.sender); }
  if(state.search){ list = list.filter(m=> (m.text||'').toLowerCase().includes(state.search)); }

  list.sort((a,b)=> new Date(a.timestamp.replace(' ','T')) - new Date(b.timestamp.replace(' ','T')));
  if(state.sort === 'desc') list.reverse();

  if(!list.length){
    const empty = el('div', 'muted text-sm', 'No messages match your filters.');
    empty.style.padding = '6px';
    wrap.appendChild(empty);
    return;
  }

  for(const m of list){ wrap.appendChild(messageEl(m)); }
  wrap.setAttribute('aria-busy', 'false');
}

function renderMetrics(){
  const root = document.getElementById('metrics');
  root.innerHTML = '';
  if(!state.metrics?.length){ root.innerHTML = '<p class="muted">No metrics available.</p>'; return; }

  const table = document.createElement('table');
  const thead = document.createElement('thead');
  thead.innerHTML = '<tr><th>Month</th><th>Doctor h</th><th>Coach h</th><th>PT h</th><th>Concierge h</th><th>Consults</th></tr>';
  const tbody = document.createElement('tbody');

  for(const row of state.metrics){
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${row.month}</td>
                    <td>${Number(row.doctor_hours).toFixed(1)}</td>
                    <td>${Number(row.coach_hours).toFixed(1)}</td>
                    <td>${Number(row.pt_hours).toFixed(1)}</td>
                    <td>${Number(row.concierge_hours).toFixed(1)}</td>
                    <td>${row.consults}</td>`;
    tbody.appendChild(tr);
  }
  table.append(thead, tbody);
  root.appendChild(table);
}

function loadingSkeleton(){
  const t = document.getElementById('timeline');
  t.innerHTML = '';
  for(let i=0;i<6;i++){
    const sk = document.createElement('div');
    sk.className = 'message';
    sk.style.opacity = 0.6;
    sk.innerHTML = `<div class="meta">Loading…</div>
                    <div class="content">███████████████ ▓▓▓▓▓▓▓▓▓▓▓ ▒▒▒▒▒▒▒▒▒▒</div>`;
    t.appendChild(sk);
  }
}

function debounce(fn, ms=200){
  let id;
  return (...args)=>{
    clearTimeout(id);
    id = setTimeout(()=> fn(...args), ms);
  };
}

async function init(){
  document.getElementById('year').textContent = new Date().getFullYear();
  loadingSkeleton();
  try{
    const [messages, events, rationales, metrics] = await Promise.all([
      loadJSON('data/messages.json'),
      loadJSON('data/events.json'),
      loadJSON('data/rationales.json'),
      loadJSON('data/metrics.json')
    ]);
    state.messages = messages;
    state.events = events;
    state.rationales = rationales;
    state.metrics = metrics;
    renderFilters();
    renderTimeline();
    renderMetrics();
  }catch(err){
    const t = document.getElementById('timeline');
    t.innerHTML = `<div class="message highlight"><div class="meta">Error</div><div>Could not load data. ${err.message}</div></div>`;
    console.error(err);
  }
}

init();
