# Elyx Hackathon — Member Journey (Rohan Patel)

This repo contains:
- `/data/*.json` — synthetic chats, events, rationales, monthly internal metrics
- `/web` — lightweight static web app to explore the journey
- `/prompts/prompts.md` — LLM prompts used

## How to run
Option A — Open the static files directly:
1. Open `web/index.html` in your browser. (If your browser blocks local fetch, start a local server.)

Option B — Run a tiny local server (Python)
```bash
cd web
python3 -m http.server 8000
# open http://localhost:8000
```

## Data format
- `messages.json`: [{ id, timestamp, sender, text, pillar?, reason?, related_ids[] }]
- `events.json`: array of `travel` | `exercise_update` | `diagnostic` items
- `rationales.json`: links decisions to event IDs for "why" traceability
- `metrics.json`: monthly rollup of internal effort and consult counts

## Assumptions encoded
- Diagnostics scheduled ~every 90 days.
- Exercise program updates every 14 days.
- Travel windows created so that ~1 week/4 weeks is away.
- Member-initiated questions limited to ~2–5 per week to meet "up to 5" guidance.
- Adherence ~50% with plan adjustments and messaging tone to support consistency.

## Notes
All messages are synthetic (no sample text reused). Health-related content is educational, not medical advice.
